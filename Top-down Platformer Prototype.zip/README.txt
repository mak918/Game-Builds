##### Platformer Prototype #####


-- Controls --
Action	Controller	Keyboard

Move 	- left stick 	- arrow keys
Jump	- south button	- c
Dash	- right trigger	- z
"Attack"- west button	- x
"Magic"	- north button	- s
dash
toggle	- east button	- a


-- Notes --

I'm looking mostly for feedback on how the movement feels in the prototype. Feel free to report any bugs found, and try to think how the movement would feel if it had actual art assets and effects.

You may have noticed that there is a button for a "dash toggle". The idea here is that there are two forms of the dash: an initial one, where only one dash can be used in the air, and there is greater time between dashes. Then, later in the game, you'll unlock un upgrade for it, that gives two dashes in the air, and reduces the time between grounded dashes. The prototype starts with the dash upgrade enabled. Pressing the dash toggle button (while all air dashes are available) will switch between having the dash upgrade and not having it.

In the play area you will also find a test dummy. You can use this as a target for your attacks (both the regular "sword" attack, and your "magic fire" attack). Touching the dummy will also knock you back as if you took damage (you don't actually take damage though). Don't mind the slightly awkward physics of it.


-- Irrelevant ramblings --

When first making the most basic form of the character, I first needed a simple shape to act as a stand-in for the character. I used a cylinder, since it roughly corresponds to the space a character would take up. I also needed to add in basic movement. Following a guide, I made some normal movement, and from it's (and many other's) recommendations, I added a box on the front of the character to show what direction it's facing. Then I needed to add a jump. Again following a guide, I made the character be able to jump, but of course it would jump whenever the button was pressed, regardless of where it was at. To fix this, I needed to add ground detection. I tried one method (a built-in method) but was having inconsitencies with how the character was reacting. In order to determine this, I added a testing feature to the character. I decided I would colour it one colour when grounded, and another blue. I didn't want to think about it much, so I just went with red and blue since they are common colours. I made red be grounded, and blue for airbourne. I also never bothered to remove this testing feature. This is the entire reason why the character looks the way it does.